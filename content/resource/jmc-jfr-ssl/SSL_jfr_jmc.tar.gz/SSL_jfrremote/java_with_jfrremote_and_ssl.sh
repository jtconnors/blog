#!/bin/bash

. include.sh

OPTS="-Dcom.sun.management.jmxremote.port=$RMIPORT
-Dcom.sun.management.jmxremote.ssl=true
-Dcom.sun.management.jmxremote.authenticate=false
-Djavax.net.ssl.keyStore=$REMOTE_KEYSTORE_DEFERRED
-Djavax.net.ssl.keyStorePassword=$KEYSTORE_PASSWORD
-Djava.rmi.server.hostname=$HOST_IPADDR
-XX:+UnlockCommercialFeatures
-XX:+FlightRecorder
-XX:FlightRecorderOptions=defaultrecording=true
"

CMD="java $OPTS $*"
echo $CMD
eval $CMD
