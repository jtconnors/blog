#!/bin/bash
. include.sh

CMD="keytool -import -alias $CLIENT_ALIAS -file $CLIENT_ALIAS.cer -keystore $CLIENT_TRUSTSTORE_DEFERRED"
echo $CMD
eval $CMD
