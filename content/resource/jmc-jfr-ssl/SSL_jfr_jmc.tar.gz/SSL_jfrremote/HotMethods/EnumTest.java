public class EnumTest {

}
