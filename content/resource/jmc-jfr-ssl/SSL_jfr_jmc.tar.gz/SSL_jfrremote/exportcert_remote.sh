#!/bin/bash

. include.sh

CMD="keytool -export -alias $REMOTE_ALIAS -keystore $REMOTE_KEYSTORE_DEFERRED -rfc -file $REMOTE_ALIAS.cer"
echo $CMD
eval $CMD
