#!/bin/bash

#
# CERTS_DIR_DEFERRED defers expansion of HOME variable so that it can be
# displayed showing $HOME string rather than expanding its value.
# CERTS_DIR contains expanded value of CERTS_DIR_DEFERRED
# 
CERTS_DIR_DEFERRED=\$HOME/.certs
CERTS_DIR=`eval echo $CERTS_DIR_DEFERRED`
#
REMOTE_ALIAS=jfrremote
REMOTE_KEYSTORE_DEFERRED=$CERTS_DIR_DEFERRED/${REMOTE_ALIAS}KeyStore
REMOTE_KEYSTORE=$CERTS_DIR/${REMOTE_ALIAS}KeyStore
REMOTE_TRUSTSTORE_DEFERRED=$CERTS_DIR_DEFERRED/${REMOTE_ALIAS}TrustStore
REMOTE_TRUSTSTORE=$CERTS_DIR/${REMOTE_ALIAS}TrustStore
#
CLIENT_ALIAS=jmc
CLIENT_KEYSTORE_DEFERRED=$CERTS_DIR_DEFERRED/${CLIENT_ALIAS}KeyStore
CLIENT_KEYSTORE=$CERTS_DIR/${CLIENT_ALIAS}KeyStore
CLIENT_TRUSTSTORE_DEFERRED=$CERTS_DIR_DEFERRED/${CLIENT_ALIAS}TrustStore
CLIENT_TRUSTSTORE=$CERTS_DIR/${CLIENT_ALIAS}TrustStore
#
RMIPORT=7091
RMIREGISTRY_PORT=7092
PASSWORD=changeit
KEYSTORE_PASSWORD=$PASSWORD
TRUSTSTORE_PASSWORD=$PASSWORD
#
# Here's some bash kludgery to get the IP address of this host.
# The assumption is that the `hostname` entry will not have
# a loopback (127.0.0.1) address in /etc/hosts
#
HOSTNAME=`hostname`
pingstr=(`ping -c 1 $HOSTNAME`)
HOST_IPADDR=`echo ${pingstr[2]:1} | sed 's/)//'`
