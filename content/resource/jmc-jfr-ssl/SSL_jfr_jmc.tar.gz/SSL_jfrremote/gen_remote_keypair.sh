#!/bin/bash

. include.sh

CMD="keytool -genkey -alias $REMOTE_ALIAS -keyalg RSA -validity 730 -keystore $REMOTE_KEYSTORE_DEFERRED"
echo $CMD
eval $CMD
