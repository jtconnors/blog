
This README.txt file is intended for Java Missoin Control clients accessing a
remote Java FLight Recorder instance from WINDOWS.  For linux/unix clients
please consult the README file.


Utilities to Aid in Setting up SSL in Conjunction with the Java Mission
Control (jmc) Client Application.

The following steps should help simplify the task of creating the necessary
crytographic keys as well as configuring the java command-line arguments for
running Java Mission Control (jmc) with an SSL-enabled remote JVM

0) Customize the include.bat file.  This file serves as a common block of
   variables.  All bat files in this directory will include this file as part
   of their execution.  Listed below are the default contents of this file.
   You may need or wish to customize some of these values.

   set CERTS_DIR=%~dp0..\.certs

   set REMOTE_ALIAS=jfrremote
   set REMOTE_KEYSTORE=%CERTS_DIR%\%REMOTE_ALIAS%KeyStore
   set REMOTE_TRUSTSTORE=%CERTS_DIR%\%REMOTE_ALIAS%TrustStore

   set CLIENT_ALIAS=jmc
   set CLIENT_KEYSTORE=%CERTS_DIR%\%CLIENT_ALIAS%KeyStore
   set CLIENT_TRUSTSTORE=%CERTS_DIR%\%CLIENT_ALIAS%TrustStore

   set RMIPORT=7091
   set RMIREGISTRY_PORT=7092
   set PASSWORD=changeit
   set KEYSTORE_PASSWORD=%PASSWORD%
   set TRUSTSTORE_PASSWORD=%PASSWORD%

   REM
   REM Here's some batch kludgery to get the IP address of this host.
   REM The assumption is that the `hostname` entry will not have
   REM a loopback (127.0.0.1) address in /etc/hosts
   REM
   for /f "tokens=2 delims=[]" %%f in ('ping -4 -n 1 %computername% ^|find /i "pinging"') do set    HOST_IPADDR=%%f

   REM echo REMOTE_ALIAS=%REMOTE_ALIAS%
   REM echo REMOTE_KEYSTORE=%REMOTE_KEYSTORE%
   REM echo REMOTE_TRUSTSTORE=%REMOTE_TRUSTSTORE%
   REM echo RMIPORT=%RMIPORT%
   REM echo RMIREGISTRY_PORT=%RMIREGISTRY_PORT%
   REM echo PASSWORD=%PASSWORD%
   REM echo KEYSTORE_PASSWORD=%KEYSTORE_PASSWORD%
   REM echo TRUSTSTORE_PASSWORD=%TRUSTSTORE_PASSWORD%
   REM echo HOST_IPADDR=%HOST_IPADDR%   


1) Once include.bat is configured to your liking, create the directory that
   will house the crytographic keys, and limit permissions.

   mkdir %CERTS_DIR%


2) *** This step assumes the remote side certificate has been created
   and transferred to this system. ***

   Import the remote certificate into the remote JVM instance's trust store.
   For this example, the password chosen is 'changeit'.  If you choose
   something different, it will need to be reflected in the include.sh file.

   $ importcert_remote.bat
   keytool -importcert -keystore %REMOTE_TRUSTSTORE% -alias %REMOTE_ALIAS% -file %REMOTE_ALIAS%.cer
   Enter keystore password:  changeit
   Re-enter new password:  changeit
   Owner: CN=Joe Schmo, OU=Acme Corp, O=Skunkworks, L=New York, ST=NY, C=US
   Issuer: CN=Joe Schmo, OU=Acme Corp, O=Skunkworks, L=New York, ST=NY, C=US
   Serial number: 257a3c40
   Valid from: Wed Jan 14 11:00:53 EST 2015 until: Fri Jan 13 11:00:53 EST 2017
   Certificate fingerprints:
	    MD5:  53:80:83:44:16:D6:14:75:91:28:D5:D2:01:14:4B:95
	    SHA1: 72:1C:9E:C3:D0:9D:3B:9E:0B:64:55:35:BE:E9:D8:E5:7A:71:96:A1
	    SHA256: 69:89:09:DB:55:FC:DF:FE:E3:00:A3:CB:2A:5B:EC:69:89:7C:3E:18:74:D4:2D:CE:F0:E5:37:37:01:4A:A9:E5
	    Signature algorithm name: SHA256withRSA
	    Version: 3
   
   Extensions: 
   
   #1: ObjectId: 2.5.29.14 Criticality=false
   SubjectKeyIdentifier [
   KeyIdentifier [
   0000: 19 C7 7B A6 65 BB D9 72   29 11 72 A6 40 68 EA BE  ....e..r).r.@h..
   0010: B3 7A 88 D3                                        .z..
   ]
   ]
   
   Trust this certificate? [no]:  yes
   Certificate was added to keystore


3) Run the genkeypair_client.sh script.  For this example, the password
   chosen is 'changeit'.  If you choose something different, it will need
   to be reflected in the include.sh file.

   $ ./genkeypair_client.sh 
   keytool -genkey -alias jmc -keyalg RSA -validity 730 -keystore $HOME/.certs/jmcKeyStore
   Enter keystore password: changeit  
   Re-enter new password:  changeit
   What is your first and last name?
     [Unknown]:  Joe Schmo
   What is the name of your organizational unit?
     [Unknown]:  Acme Corp
   What is the name of your organization?
     [Unknown]:  Skunkworks
   What is the name of your City or Locality?
     [Unknown]:  New York
   What is the name of your State or Province?
     [Unknown]:  NY
   What is the two-letter country code for this unit?
     [Unknown]:  US
   Is CN=Joe Schmo, OU=Acme Corp, O=Skunkworks, L=New York, ST=NY, C=US correct?
     [no]:  yes

   Enter key password for <jmc>
	   (RETURN if same as keystore password): <RETURN>


4) Export the certificate associated with the recently generated key pair.
   This will be used by the remote JVM instance and also has to be imported
   into the trust store of the client application
   (Java Mission Control or jmc).

   $ ./exportcert_client.bat
   keytool -export -alias %CLIENT_ALIAS% -keystore %CLIENT_KEYSTORE% -rfc -file %CLIENT_ALIAS%.cer
   Enter keystore password: changeit 
   Certificate stored in file <jmc.cer>


5) Securely transfer the recentely created certificate
   to the remote JVM instance


6) When remote and client key stores and trust stores have been established,
   and when the remote JVM is running with the proper command-line
   SSL and Java FLight Recorder arguments, start up the Java Mission Control
   (jmc) application with the jmc_with_ssl.bat file:

   $ ./jmc_with_ssl.bat
   jmc -vmargs -Djavax.net.ssl.trustStore=%REMOTE_TRUSTSTORE% -Djavax.net.ssl.trustStorePassword=%TRUSTSTORE_PASSWORD% -Djavax.net.ssl.keyStore=%CLIENT_KEYSTORE%  -Djavax.net.ssl.keyStorePassword=%KEYSTORE_PASSWORD%
   
