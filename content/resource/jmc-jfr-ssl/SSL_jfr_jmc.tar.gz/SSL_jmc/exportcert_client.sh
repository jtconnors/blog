#!/bin/bash

. include.sh

CMD="keytool -export -alias $CLIENT_ALIAS -keystore $CLIENT_KEYSTORE_DEFERRED -rfc -file $CLIENT_ALIAS.cer"
echo $CMD
eval $CMD
