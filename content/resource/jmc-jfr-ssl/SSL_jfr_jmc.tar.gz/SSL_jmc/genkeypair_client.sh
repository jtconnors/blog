#!/bin/bash
. include.sh

CMD="keytool -genkey -alias $CLIENT_ALIAS -keyalg RSA -validity 730 -keystore $CLIENT_KEYSTORE_DEFERRED"
echo $CMD
eval $CMD
