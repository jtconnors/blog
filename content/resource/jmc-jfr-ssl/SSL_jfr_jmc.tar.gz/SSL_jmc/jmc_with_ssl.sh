#!/bin/bash

. include.sh 

OPTS="
-vmargs
-Djavax.net.ssl.trustStore=$REMOTE_TRUSTSTORE
-Djavax.net.ssl.trustStorePassword=$TRUSTSTORE_PASSWORD
-Djavax.net.ssl.keyStore=$CLIENT_KEYSTORE
-Djavax.net.ssl.keyStorePassword=$KEYSTORE_PASSWORD
"

DEBUGOPTS=""
#DEBUGOPTS="-Djavax.net.debug=ssl -debug"

CMD="jmc $OPTS $DEBUGOPTS"
echo $CMD
eval $CMD
