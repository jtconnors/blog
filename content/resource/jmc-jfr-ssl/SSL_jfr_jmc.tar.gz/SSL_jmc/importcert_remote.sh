#!/bin/bash

. include.sh

CMD="keytool -importcert -keystore $REMOTE_TRUSTSTORE_DEFERRED -alias $REMOTE_ALIAS -file $REMOTE_ALIAS.cer"
echo $CMD
eval $CMD
