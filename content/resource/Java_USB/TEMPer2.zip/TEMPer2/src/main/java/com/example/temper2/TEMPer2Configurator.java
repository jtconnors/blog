
package com.example.temper2;

import java.io.IOException;
import java.util.Dictionary;
import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.service.cm.Configuration;
import org.osgi.service.cm.ConfigurationAdmin;
import org.osgi.service.cm.ConfigurationException;
import org.osgi.service.cm.ManagedService;

public class TEMPer2Configurator implements ManagedService {
    /*
     * Configuration admin attributes and their corresponding default values
     * and variables.
     */
    private static final String VENDOR_ID_ATTR = "vendorId";
    private static final int DEFAULTVAL_VENDOR_ID = 3141;

    private static final String PRODUCT_ID_ATTR = "productId";
    private static final int DEFAULTVAL_PRODUCT_ID = 29697;

    private static final String INTERFACE_NUM_ATTR = "interfaceNum";
    private static final int DEFAULTVAL_INTERFACE_NUM = 1;

    private final BundleContext bundleContext;

    @Override
    public void updated(Dictionary<String, ?> dctnr)
            throws ConfigurationException {
    }

    /*
     * Get the Configuration object from the Configuration Admin Service.
     */
    private Configuration getConfiguration() {
        /*
         * The PID (Persistent Identifier) for this object is set to be the
         * name of the TEMPer2Configurator class.
         */
        try {
            ServiceReference<ConfigurationAdmin> caRef
                    = bundleContext.getServiceReference(ConfigurationAdmin.class);
            ConfigurationAdmin configAdmin = bundleContext.getService(caRef);
            return configAdmin.getConfiguration(TEMPer2Configurator.class.getName());
        } catch (IOException ex) {
            Logger.getLogger(Activator.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    private Dictionary<String, Object> getConfigurationProperties() {
        return getConfiguration().getProperties();
    }

    /*
     * Store the attribute-value pair in the Configuration properties
     */
    public void setConfigValue(String attribute, String value)
            throws IOException {
        Dictionary<String, Object> properties = getConfigurationProperties();
        properties.put(attribute, value);
        getConfiguration().update(properties);
    }

    /*
     * Get the value associated with the specified attribute from the
     * configuration properties.
     */
    public String getConfigValue(String attribute)
            throws IOException {
        Dictionary<String, Object> properties = getConfigurationProperties();
        return (String) properties.get(attribute);
    }

    /*
     * Get the value associated with the specified attribute from the
     * configuration properties.  If no attribute-value pair exists in the
     * properties, create one and assign it the value specified by the
     * defaultValue argument.
     */
    public String getOrInitConfigValue(String attribute, String defaultValue)
            throws IOException {
        Dictionary<String, Object> properties = getConfigurationProperties();
        String value = (String) properties.get(attribute);
        if (value == null) {
            setConfigValue(attribute, defaultValue);
            return defaultValue;
        }
        return value;
    }
    
    public int getVendorId() throws IOException {
        return Integer.valueOf(
                getOrInitConfigValue(VENDOR_ID_ATTR,
                        String.valueOf(DEFAULTVAL_VENDOR_ID)));
    }

    public int getProductId() throws IOException {
        return Integer.valueOf(
                getOrInitConfigValue(PRODUCT_ID_ATTR,
                        String.valueOf(DEFAULTVAL_PRODUCT_ID)));
    }

    public int getInterfaceNum() throws IOException {
        return Integer.valueOf(
                getOrInitConfigValue(INTERFACE_NUM_ATTR,
                        String.valueOf(DEFAULTVAL_INTERFACE_NUM)));
    }

    public void InitProperties() throws IOException {
        Configuration configuration = getConfiguration();

        /*
         * Get the properties defined by the TEMPer2Configurator
         * configuration.  If it hasn't been defined yet, create it now.
         */
        Dictionary<String, Object> properties = getConfigurationProperties();
        if (properties == null) {
            properties = new Hashtable<>();
            configuration.update(properties);
        }
        /*
         * Make sure Configuration has the defined attribute-value pairs
         */
        getOrInitConfigValue(VENDOR_ID_ATTR,
                Integer.toString(DEFAULTVAL_VENDOR_ID));
        getOrInitConfigValue(PRODUCT_ID_ATTR,
                Integer.toString(DEFAULTVAL_PRODUCT_ID));
        getOrInitConfigValue(INTERFACE_NUM_ATTR,
                Integer.toString(DEFAULTVAL_INTERFACE_NUM));
    }

    public TEMPer2Configurator(BundleContext bundleContext) {
        this.bundleContext = bundleContext;
    }
}
