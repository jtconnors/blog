
package com.example.temper2;

import com.codeminders.hidapi.HIDDevice;
import com.codeminders.hidapi.HIDDeviceInfo;
import com.codeminders.hidapi.HIDManager;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TEMPer2 {
    
    static final int BUFSIZE = 2048;
    static final long READ_UPDATE_DELAY_MS = 1000;
    
    private static TEMPer2Configurator temper2Configurator;
    
    public TEMPer2(TEMPer2Configurator temper2Configurator) {
        TEMPer2.temper2Configurator =  temper2Configurator;  
    } 
    
    public TEMPer2() {
    }

    static float raw_to_c(int rawtemp) {
        float temp_c = rawtemp * (125.f / 32000.f);
        return temp_c;
    }

    static float c_to_u(float deg_c, char unit) {
        if (unit == 'F') {
            return (deg_c * 1.8f) + 32.f;
        } else if (unit == 'K') {
            return (deg_c + 273.15f);
        } else {
            return deg_c;
        }
    }
    
    private static String findDevicePath(int vendorId, int productId,
            int interfaceNum) {
        try {
            HIDManager manager = HIDManager.getInstance();
            if (manager == null) {
                return null;
            }
            HIDDeviceInfo[] devs = manager.listDevices();
            if (devs != null) {
                for (HIDDeviceInfo device : devs) {
                    if (device.getVendor_id() == vendorId
                            && device.getProduct_id() == productId
                            && device.getInterface_number() == interfaceNum) {
                        return device.getPath();
                    }
                }
            }
        } catch (IOException ex) {
            Logger.getLogger(TEMPer2.class.getName()).
                    log(Level.INFO, "TEMPer2: {0}",
                            Arrays.toString(ex.getStackTrace()));
        }
        return null;
    }
    
    public TEMPer2Reading readTemps() {
        TEMPer2Reading tempReadings = new TEMPer2Reading();
        HIDDevice dev;
        try {
            HIDManager hid_mgr = HIDManager.getInstance();
            String pathID = findDevicePath(
                    temper2Configurator.getVendorId(),
                    temper2Configurator.getProductId(),
                    temper2Configurator.getInterfaceNum());
            if (pathID == null) {
                String msg = "Could Not find device: vendor=" +
                        temper2Configurator.getVendorId() + " product=" + 
                        temper2Configurator.getProductId() +
                        " interface number=" + 
                        temper2Configurator.getInterfaceNum();
                Logger.getLogger(TEMPer2.class.getName()).
                log(Level.INFO, "TEMPer2: {0}", msg);
                return tempReadings;
            }
            dev = hid_mgr.openByPath(pathID);

            byte[] instructions = new byte[]{
                (byte) 0x01, (byte) 0x80, (byte) 0x33, (byte) 0x01,
                (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00
            };

            dev.disableBlocking();
            int res = dev.write(instructions);

            try {
                try {
                    Thread.sleep(READ_UPDATE_DELAY_MS);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                byte[] buf = new byte[BUFSIZE];
                int n = dev.read(buf);

                int rawTemp = (buf[3] & (byte) 0xFF) + (buf[2] << 8);
                if ((buf[2] & 0x80) != 0) {
                    /* return the negative of magnitude of the temperature */
                    rawTemp = -((rawTemp ^ 0xffff) + 1);
                }
                // Convert temp and round to two decimal places
                DecimalFormat df = new DecimalFormat("#.##");
                String roundedStr = df.format(c_to_u(raw_to_c(rawTemp), 'C'));
                tempReadings.setInternalTemp(roundedStr);                
                /*
                 * JTC -- get external temp from TEMPer2
                 */
                rawTemp = (buf[5] & (byte) 0xFF) + (buf[4] << 8);
                if ((buf[4] & 0x80) != 0) {
                    /* return the negative of magnitude of the temperature */
                    rawTemp = -((rawTemp ^ 0xffff) + 1);
                }
                // Convert temp and round to two decimal places
                roundedStr = df.format(c_to_u(raw_to_c(rawTemp), 'C'));
                tempReadings.setExternalTemp(roundedStr);
                /*
                 * End get external temp from TEMPer2
                 */

                try {
                    Thread.sleep(READ_UPDATE_DELAY_MS);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            } finally {
                dev.close();
                hid_mgr.release();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return tempReadings;
    }   
}
