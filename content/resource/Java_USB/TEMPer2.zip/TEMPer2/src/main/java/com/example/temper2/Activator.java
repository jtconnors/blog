package com.example.temper2;

import java.util.Hashtable;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.service.cm.ManagedService;

public class Activator implements BundleActivator {

    private BundleContext bundleContext;
    private TEMPer2Configurator temper2Configurator;

    @Override
    public void start(BundleContext context) throws Exception {
        this.bundleContext = context;
        /*
         * Register TEMPer2Configurator as a Managed Service
         */
        Hashtable<String, String> props = new Hashtable<>();
        props.put("service.pid", TEMPer2Configurator.class.getName());
        temper2Configurator = new TEMPer2Configurator(bundleContext);
        bundleContext.registerService(ManagedService.class.getName(),
                temper2Configurator, props);
        
        temper2Configurator.InitProperties();
        
        /*
         * Get a temperature reading to make sure things are set up
         */
        TEMPer2 temper2 = new TEMPer2(temper2Configurator);
        Logger.getLogger(Activator.class.getName()).
                log(Level.INFO, "TEMPer2: {0}", temper2.readTemps().toString());

    }

    @Override
    public void stop(BundleContext context) throws Exception {
        // TODO add deactivation code here
    }

}
