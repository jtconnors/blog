
package com.example.temper2;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.ZonedDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TEMPer2Reading {
    
    public final static String ABSOLUTE_ZERO = "-273.15";
    
    private final String hostName;
    private final ZonedDateTime dateTime;
    private String internalTemp;
    private String externalTemp;
    
    public TEMPer2Reading() {
        hostName = getHostNameAtCreation();
        dateTime = getDateTimeAtCreation();
        internalTemp = ABSOLUTE_ZERO;
        externalTemp = ABSOLUTE_ZERO;
    }
    
    private String getHostNameAtCreation() {
        String host = null;
        try {
            host = InetAddress.getLocalHost().getHostName();
        } catch (UnknownHostException ex) {
            Logger.getLogger(TEMPer2Reading.class.getName()).
                    log(Level.SEVERE, null, ex);
        }
        return host;
    }
    
    private ZonedDateTime getDateTimeAtCreation() {
        return ZonedDateTime.now();
    }
    
    public String getZonedDateTime() {
        return dateTime.toString();
    }
    
    public String getTime() {
        StringBuilder sb = new StringBuilder();
        sb.append(dateTime.getHour());
        sb.append(":");
        sb.append(dateTime.getMinute());
        sb.append(":");
        sb.append(dateTime.getSecond());
        return new String(sb);
    }

    public String getHostName() {
        return hostName;
    }

    public String getInternalTemp() {
        return internalTemp;
    }
    
    public String getExternalTemp() {
        return externalTemp;
    }
    
    public void setInternalTemp(String internalTemp) {
        this.internalTemp = internalTemp;
    }
    
    public void setExternalTemp(String externalTemp) {
        this.externalTemp = externalTemp;
    }
    
    @Override
    public String toString() {
       StringBuilder sb = new StringBuilder();
       sb.append(hostName);
       sb.append(" ");
       sb.append(dateTime.toString());
       sb.append(" internal temp: ");
       sb.append(internalTemp);
       sb.append("C, external temp: ");
       sb.append(externalTemp);
       sb.append("C");
       return new String(sb);
    }
}
