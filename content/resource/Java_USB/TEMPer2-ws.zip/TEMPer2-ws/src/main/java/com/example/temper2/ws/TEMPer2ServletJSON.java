package com.example.temper2.ws;

import com.example.temper2.TEMPer2;
import com.example.temper2.TEMPer2Reading;
import java.io.IOException; 
import java.io.PrintWriter;
import javax.json.Json;
import javax.json.JsonBuilderFactory;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonWriter;
import javax.json.JsonWriterFactory;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class TEMPer2ServletJSON extends HttpServlet {
    
    private static final JsonBuilderFactory bf = Json.createBuilderFactory(null);
    private static final JsonWriterFactory wf = Json.createWriterFactory(null);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse response)
            throws ServletException, IOException {

        /*
         * The contentType should normally be "application/json" for security
         * reasons so that the browser won't display potentially unwanted
         * information.  We actually want this to be text/html in this case
         * for demonstration purposes in order to view the generated JSON code.
         */
        response.setContentType("text/html;charset=UTF-8");
        /*
         * Need to set the following header to allow cross-domain javascript
         * requests.  See W3C CORS (Cross-Origin Resource Sharing).
         */
        response.setHeader("Access-Control-Allow-Origin", "*");
        
        TEMPer2 temper2 = new TEMPer2();
        TEMPer2Reading tempReading = temper2.readTemps();
    
        JsonObjectBuilder tempReadingBuilder = bf.createObjectBuilder();
        tempReadingBuilder.add("hostName", tempReading.getHostName())
                .add("zonedDateTime", tempReading.getZonedDateTime())
                .add("time", tempReading.getTime())
                .add("internalTemp", tempReading.getInternalTemp())
                .add("externalTemp", tempReading.getExternalTemp());
        
        JsonObject tempReadingJsonObject = tempReadingBuilder.build();      
        PrintWriter out = response.getWriter();
        JsonWriter jsonWriter = wf.createWriter(out);
        
        try {
            jsonWriter.writeObject(tempReadingJsonObject);
        } finally {
            if (out != null) {
                jsonWriter.close();
                out.close();
            }
        }
    }

}
