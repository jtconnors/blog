package com.example.temper2.ws;

import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.service.http.HttpService;

public class Activator implements BundleActivator {

    @Override
    public void start(BundleContext context) throws Exception {
        ServiceReference sRef = context.getServiceReference(HttpService.class
                .getName());
        if (sRef != null) {
            HttpService service = (HttpService) context.getService(sRef);
            service.registerServlet("/TEMPer2",
                    new TEMPer2Servlet(), null, null);
            service.registerServlet("/TEMPer2.json",
                    new TEMPer2ServletJSON(), null, null);
        }
    }

    @Override
    public void stop(BundleContext context) {
    }
}
