package com.example.temper2.ws;

import com.example.temper2.TEMPer2;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class TEMPer2Servlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        
        TEMPer2 temper2 = new TEMPer2();
        String reading = temper2.readTemps().toString();

        try {
            out.println("<html>");
            out.println("<head>");
            out.println("<title>TEMPer2</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h3>" + reading + "</h3>");
            out.println("</body>");
            out.println("</html>");
        } finally {
            if (out != null) {
                out.close();
            }
        }
    }

}
