function showBulbClockNodeApplet() { 
    document.getElementById("BulbClockNodeApplet").innerHTML = "<IFRAME alt=ShoppingService scrolling=no frameborder=0 src=http://blogs.sun.com/jtc/resource/javafx-node-perf/BulbClockNode.html height=160 width=400 ></IFRAME>"; 
}

