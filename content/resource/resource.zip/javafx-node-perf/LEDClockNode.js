function showLEDClockNodeApplet() { 
    document.getElementById("LEDClockNodeApplet").innerHTML = "<IFRAME alt=ShoppingService scrolling=no frameborder=0 src=http://blogs.sun.com/jtc/resource/javafx-node-perf/LEDClockNode.html height=160 width=400 ></IFRAME>"; 
}

