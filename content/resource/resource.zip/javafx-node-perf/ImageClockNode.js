function showImageClockNodeApplet() { 
    document.getElementById("ImageClockNodeApplet").innerHTML = "<IFRAME alt=ShoppingService scrolling=no frameborder=0 src=http://blogs.sun.com/jtc/resource/javafx-node-perf/ImageClockNode.html height=160 width=400 ></IFRAME>"; 
}

