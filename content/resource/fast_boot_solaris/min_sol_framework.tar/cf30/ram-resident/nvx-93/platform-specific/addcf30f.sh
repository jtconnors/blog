#!/bin/sh

#
# addcf30f.sh -  Add/Remove Panasonic Toughbook CF-30 Rev. F specific
#                content to the miniroot
#
#               This script is typically invoked from ant and has the
#               following arguments: 
#
#               $1: miniroot_directory
#               $2: cf30f_directory -- containing cf30f specific content
#

PROGNAME=$0
SYNTAX="${PROGNAME} minroot_directory cf30f_directory"

. ../include/utils.sh

if [ $# != 2 ] ; then
	arg_error "wrong number of arguments" "${SYNTAX}"
fi

MINIROOTDIR=$1
if [ ! -d "${MINIROOTDIR}" ] ; then
        arg_error "${MINIROOTDIR} directory does not exist" "${SYNTAX}"
fi
if [ "${MINIROOTDIR}" = "/" ] ; then
        arg_error "'/' is definitely not a valid miniroot directory" "${SYNTAX}"
fi

CF30FDIR=$2
if [ ! -d "${CF30FDIR}" ] ; then
        arg_error "${CF30FDIR} directory does not exist" "${SYNTAX}"
fi

cd ${MINIROOTDIR}

#
# Add Marvell Yukon2 ethernet driver
#
#msg_to_stderr "adding myk driver to /kernel/drv"
#if [ ! -f ${CF30FDIR}/myk ] ; then
#    arg_error "myk dirver not found" "${SYNTAX}"
#fi
#cp ${CF30FDIR}/myk ${MINIROOTDIR}/kernel/drv

# 
# Possible driver_aliases entries based upon OEMs of this chipset.
# (Taken from adddrv.sh script, saved in this directory for posterity)
#
DEVLIST=""
DEVLIST=${DEVLIST}" "'"pci1148,9000"'	# SK-9SXX
DEVLIST=${DEVLIST}" "'"pci1148,9e00"'	# SK-9EXX
DEVLIST=${DEVLIST}" "'"pci11ab,4340"' 	# 88E8021CU
DEVLIST=${DEVLIST}" "'"pci11ab,4341"' 	# 88E8022CU
DEVLIST=${DEVLIST}" "'"pci11ab,4342"' 	# 88E8061CU
DEVLIST=${DEVLIST}" "'"pci11ab,4343"' 	# 88E8062CU
DEVLIST=${DEVLIST}" "'"pci11ab,4344"' 	# 88E8021SX
DEVLIST=${DEVLIST}" "'"pci11ab,4345"' 	# 88E8022SX
DEVLIST=${DEVLIST}" "'"pci11ab,4346"' 	# 88E8061SX
DEVLIST=${DEVLIST}" "'"pci11ab,4347"' 	# 88E8062SX
DEVLIST=${DEVLIST}" "'"pci11ab,4350"' 	# 88E8035
DEVLIST=${DEVLIST}" "'"pci11ab,4351"' 	# 88E8036
DEVLIST=${DEVLIST}" "'"pci11ab,4352"' 	# 88E8038 (FE)
DEVLIST=${DEVLIST}" "'"pci11ab,4353"' 	# 88E8039 (FE?)
DEVLIST=${DEVLIST}" "'"pci11ab,4354"' 	# 88E8040 (FE+)
DEVLIST=${DEVLIST}" "'"pci11ab,4355"' 	# 88E8040T (FE?)
DEVLIST=${DEVLIST}" "'"pci11ab,4356"' 	# 88EC033
DEVLIST=${DEVLIST}" "'"pci11ab,4357"' 	# 88E8042 (FE?)
DEVLIST=${DEVLIST}" "'"pci11ab,435a"' 	# 88E8048 (FE?)
DEVLIST=${DEVLIST}" "'"pci11ab,4360"' 	# 88E8052 (EC)
DEVLIST=${DEVLIST}" "'"pci11ab,4361"' 	# 88E8050 (EC)
DEVLIST=${DEVLIST}" "'"pci11ab,4362"' 	# 88E8053 (EC)
DEVLIST=${DEVLIST}" "'"pci11ab,4363"' 	# 88E8055
DEVLIST=${DEVLIST}" "'"pci11ab,4364"' 	# 88E8056
DEVLIST=${DEVLIST}" "'"pci11ab,4365"' 	# 88E8070
DEVLIST=${DEVLIST}" "'"pci11ab,4366"' 	# 88EC036
DEVLIST=${DEVLIST}" "'"pci11ab,4367"' 	# 88EC032
DEVLIST=${DEVLIST}" "'"pci11ab,4368"' 	# 88EC034
DEVLIST=${DEVLIST}" "'"pci11ab,4369"' 	# 88EC042
DEVLIST=${DEVLIST}" "'"pci11ab,436a"' 	# 88E8058 (EC Ultra)
DEVLIST=${DEVLIST}" "'"pci11ab,436b"' 	# 88E8071
DEVLIST=${DEVLIST}" "'"pci11ab,436c"' 	# 88E8072
DEVLIST=${DEVLIST}" "'"pci11ab,436d"' 	# 88E8055
DEVLIST=${DEVLIST}" "'"pci11ab,4370"' 	# 88E8075

ADD_DEVLIST=""
for i in ${DEVLIST}
do
    grep ${i} ${MINIROOTDIR}/etc/driver_aliases > /dev/null 2>&1
    if [ $? -ne 0 ] ; then
        ADD_DEVLIST=${ADD_DEVLIST}" "${i}
    fi
done

#
# Add Marvell Yukon2 ethernet driver
#
msg_to_stderr "adding myk driver to /kernel/drv"
if [ ! -f ${CF30FDIR}/myk ] ; then
    arg_error "myk dirver not found" "${SYNTAX}"
fi
cp ${CF30FDIR}/myk ${MINIROOTDIR}/kernel/drv
add_drv -b ${MINIROOTDIR} -n -v -m '* 0600 root sys' -i "${ADD_DEVLIST}" myk >&2

exit 0
