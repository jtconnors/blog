#!/bin/sh

#
# setupsmf.sh - Customize SMF for this miniroot configuration
#
#               This script is typically invoked from ant and has the
#               following arguments: 
#
#               $1: miniroot_directory
#               $2: smf_directory: where customized SMF manifests and
#                                  methods exist
#

PROGNAME=$0
SYNTAX="${PROGNAME} minroot_directory smf_directory"

. ../include/utils.sh


if [ $# != 2 ] ; then
	arg_error "wrong number of arguments" "${SYNTAX}"
fi

MINIROOTDIR=$1
if [ ! -d "${MINIROOTDIR}" ] ; then
        arg_error "${MINIROOTDIR} directory does not exist" "${SYNTAX}"
fi
if [ "${MINIROOTDIR}" = "/" ] ; then
        arg_error "'/' is definitely not a valid miniroot directory" "${SYNTAX}"
fi

SMFDIR=$2
if [ ! -d "${SMFDIR}" ] ; then
        arg_error "${SMFDIR} directory does not exist" "${SYNTAX}"
fi

cd ${MINIROOTDIR}

#
# Set the environment variables for svccfg.
#
msg_to_stderr "customize SMF services"
SVCCFG_DTD=${MINIROOTDIR}/usr/share/lib/xml/dtd/service_bundle.dtd.1
SVCCFG_REPOSITORY=${MINIROOTDIR}/etc/svc/repository.db
SVCCFG=/usr/sbin/svccfg

export SVCCFG_DTD SVCCFG_REPOSITORY SVCCFG

${SVCCFG} import ${MINIROOTDIR}/var/svc/manifest/milestone/sysconfig.xml

#
# turnoff boot-archive, manifest-import
#
${SVCCFG} -s system/boot-archive setprop start/exec=:true
${SVCCFG} -s system/manifest-import setprop start/exec=:true
${SVCCFG} -s network/rpc/bind delpg sysidtool
${SVCCFG} -s system/metainit:default setprop general/enabled=false

#
# Use Modified fs-minimal service which:
#    (1) Mounts /var as a tmpfs
#
msg_to_stderr "modifying filesystem/minimal service"
cp ${SMFDIR}/fs-minimal ./lib/svc/method/
chown root:bin ./lib/svc/method/fs-minimal
chmod 555 ./lib/svc/method/fs-minimal
${SVCCFG} import ${MINIROOTDIR}/var/svc/manifest/system/filesystem/minimal-fs.xml

#
# Here's what needed to add ssh to the miniroot
#
msg_to_stderr "adding system/cryptosvc manifest needed for ssh"
${SVCCFG} import ${MINIROOTDIR}/var/svc/manifest/system/cryptosvc.xml
${SVCCFG} -s system/cryptosvc:default setprop general/enabled=true

msg_to_stderr "adding network/inetd manifest needed for ssh"
${SVCCFG} import ${MINIROOTDIR}/var/svc/manifest/network/inetd.xml
${SVCCFG} -s network/inetd:default setprop general/enabled=true

msg_to_stderr "adding network/rpc/gss manifest needed for ssh"
${SVCCFG} import ${MINIROOTDIR}/var/svc/manifest/network/rpc/gss.xml
${SVCCFG} -s network/rpc/gss:default setprop general/enabled=true

msg_to_stderr "adding network/ssh manifest"
${SVCCFG} import ${MINIROOTDIR}/var/svc/manifest/network/ssh.xml
${SVCCFG} -s network/ssh:default setprop general/enabled=true

msg_to_stderr "create RSA/DSA keys for ssh"
/usr/bin/ssh-keygen -q -f ${MINIROOTDIR}/etc/ssh/ssh_host_rsa_key -t rsa -N ''
/usr/bin/ssh-keygen -q -f ${MINIROOTDIR}/etc/ssh/ssh_host_dsa_key -t dsa -N ''

msg_to_stderr "edit etc/ssh/sshd_config to allow ssh to root account"
ex -s ${MINIROOTDIR}/etc/ssh/sshd_config > /dev/null << END_OF_INPUT 
/PermitRootLogin
s/no/yes
w!
q
END_OF_INPUT
#
# Add a "root" password to the root account.  This is needed for ssh.
#
msg_to_stderr "adding \"root\" password to root account"
ex -s ${MINIROOTDIR}/etc/shadow << END_OF_INPUT 
1d
i
root:v.ggSHu1CbWSo:13362::::::
.
w!
q
END_OF_INPUT
# End ssh stuff

exit 0
