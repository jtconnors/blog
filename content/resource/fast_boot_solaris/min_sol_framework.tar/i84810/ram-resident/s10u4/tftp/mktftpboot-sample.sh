#!/bin/sh

#
# mktftpboot-sample.sh - Create sample tftpboot directory to facilitate
#                        PXE boot of image
#
#               This script is typically invoked from ant and has the
#               following arguments: 
#
#               $1: base directory
#		$2: Bootable OS image name
#		$3: OpenSolaris/Solaris distro containing Boot files
#		$4: DHCP Identifier ("01" + MAC Address)

PROGNAME=$0
SYNTAX="${PROGNAME} base directory os_image os_distro_directory dhcp_id"

. ../include/utils.sh

if [ $# != 4 ] ; then
	arg_error "wrong number of arguments" "${SYNTAX}"
fi

BASEDIR=$1
if [ ! -d "${BASEDIR}" ] ; then
        arg_error "${BASEDIR} directory does not exist" "${SYNTAX}"
fi
if [ "${BASEDIR}" = "/" ] ; then
        arg_error "'/' is definitely not a valid base directory" "${SYNTAX}"
fi
MINIROOTDIR=${BASEDIR}/miniroot

IMAGE=$2

OS_DISTRO=$3
if [ ! -d "${OS_DISTRO}" ] ; then
        arg_error "${OS_DISTRO} directory does not exist" "${SYNTAX}"
fi
if [ "${OS_DISTRO}" = "/" ] ; then
        arg_error "'/' is definitely not a valid OS distro directory" "${SYNTAX}"
fi

DHCP_ID=$4

TFTPBOOT_SAMPLEDIR=${BASEDIR}/tftpboot-sample
/bin/rm -rf ${TFTPBOOT_SAMPLEDIR}
msg_to_stderr "creating ${TFTPBOOT_SAMPLEDIR}"
mkdir ${TFTPBOOT_SAMPLEDIR}

#
# Create the grub menu.lst file and append the DHCP_ID onto then end of the
# file name (e.g. menu.lst.01004063DEF5B5).
#
MENU_LST_FILE=${TFTPBOOT_SAMPLEDIR}/menu.lst.${DHCP_ID}
msg_to_stderr "creating ${MENU_LST_FILE}"
echo "default=0" > ${MENU_LST_FILE}
echo "timeout=5" >> ${MENU_LST_FILE}
echo "title Embedded Solaris ${IMAGE}" >> ${MENU_LST_FILE}
echo "\tkernel /boot/multiboot" >> ${MENU_LST_FILE}
echo "\tmodule /boot/${IMAGE}.gz" >> ${MENU_LST_FILE}

#
# Copy over the 32-bit boot environment from the OS image
#
msg_to_stderr "creating 32-bit network boot environment"
if [ ! -d "${OS_DISTRO}" ] ; then
        errormsg_and_exit "${OS_DISTRO} directory does not exist"
fi
cd ${OS_DISTRO}
DIRS="boot/grub"
for d in ${DIRS}
do
	if [ ! -d "${OS_DISTRO}/${d}" ] ; then
        	errormsg_and_exit "${OS_DISTRO}/${d} directory does not exist"
	fi
	tar cf - ${d} | (cd ${TFTPBOOT_SAMPLEDIR}; tar xfp -)
done
if [ ! -f "${OS_DISTRO}/boot/grub/pxegrub" ] ; then
       	errormsg_and_exit "${OS_DISTRO}/boot/grub/pxegrub does not exist"
fi
cp boot/multiboot ${TFTPBOOT_SAMPLEDIR}/boot
cp boot/grub/pxegrub ${TFTPBOOT_SAMPLEDIR}

#
# Copy over embedded bootable OS image
#
msg_to_stderr "copying ${IMAGE}.gz to ${TFTPBOOT_SAMPLEDIR}/boot/grub"
if [ ! -f "${BASEDIR}/boot/${IMAGE}.gz" ] ; then
       	errormsg_and_exit "${BASEDIR}/boot/${IMAGE}.gz does not exist"
fi
cp ${BASEDIR}/boot/${IMAGE}.gz ${TFTPBOOT_SAMPLEDIR}/boot

exit 0
