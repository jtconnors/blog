<!--
drawTREmbed( '<div id="technorati">' +
'<form id="te_s" method="post" action="http://www.technorati.com/search.php">' +
'<label for="te_search">Search this blog:</label> <input id="te_search" type="text" size="12" name="s" maxlength="255" />' +
'<input type=\"submit\" class=\"btn\" value=\"Search\" /> <input type=\"hidden\" name=\"sub\" value=\"searchlet\" /> <input type=\"hidden\" name=\"from\" value=\"http://uadmin.blogspot.com\" /> <input type=\"hidden\" name=\"cc\" value=\"9pkqfrxceg\" /> </form>' +
'<p id="te_l" class="te_l">' +
'<a href="http://www.technorati.com/search/http://uadmin.blogspot.com?cc=9pkqfrxceg" id="te_lh">&#187 Blogs that link here</a>' +
'</p>' +
'<p id="te_lo" class="te_lo"><a href="http://www.technorati.com/?cc=9pkqfrxceg"><img border="0" src="http://static.technorati.com/pix/tn-tiny.gif" alt="Powered by Technorati" /></a></p>' +
'</div>'
);


function drawTREmbed(s){
    document.write(s);
}
// -->
