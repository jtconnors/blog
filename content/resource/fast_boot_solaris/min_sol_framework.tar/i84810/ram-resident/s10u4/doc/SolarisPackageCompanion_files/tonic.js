function openBrWindow(theURL,winName,features) {
    window.open(theURL,winName,features);
}
function openPopWindow(theURL,winName) {
    window.open(theURL,winName,'scrollbars=yes,resizable=yes,width=600,height=500').focus();
}
function tnGetElementById(e)
{
    if (document.getElementById) {
        return document.getElementById(e);
    }
    if (document.all) {
        return document.all[e];
    }
    return null;
}
function readCookie(name) {
    var cookieValue;
    var search = name + "=";
    var offset;

    if (document.cookie.length > 0) {
        offset = document.cookie.indexOf(search);
        if (offset != -1) {
            offset += search.length;
            end = document.cookie.indexOf(";", offset);
            if (end == -1) {
                end = document.cookie.length;
            }
            cookieValue = unescape(document.cookie.substring(offset, end))
        }
    }
    return cookieValue;
}

function writeCookie(name, value, hours) {
    var expire = "";
    if (hours != null) {
        expire = new Date((new Date()).getTime() + hours * 3600000);
        expire = "; expires=" + expire.toGMTString();
    }
    document.cookie = name + "=" + escape(value) + expire;
}

function drawArchiveToggle(archive, initialState, cookieSetsState) {
    var toggleParent;
    var toggleSpan;
    var toggleLink;
    var cookieState = readCookie (document.body.id + '.' + archive + '-toggle-state');

    // If we're dealing with a browser that can handle DOM manipulation...
    if (document.createTextNode) {

        // If cookie state overrides initialState and a cookie was found, update initialState.
        if (cookieSetsState && cookieState) {
            initialState = cookieState;
        }

        // Find the archive header. If this fails, abort.
        toggleParent = tnGetElementById(archive + 'ArchiveHeader')
        if (!toggleParent) {
            return;
        }

        // Build link.
        toggleLink = document.createElement('a');
        toggleLink.id = archive + 'ArchiveToggleLink';
        toggleLink.href = 'javascript:toggleArchive(\'' + archive + '\')';
        toggleLink.appendChild(document.createTextNode('hide'));

        // Build span.
        toggleSpan = document.createElement('span');
        toggleSpan.className = 'ArchiveToggle';
        toggleSpan.appendChild(document.createTextNode('['));
        toggleSpan.appendChild(toggleLink);
        toggleSpan.appendChild(document.createTextNode(']'));

        // Add span to archive header.
        toggleParent.appendChild(document.createTextNode(' '));
        toggleParent.appendChild(toggleSpan);

        // If the initial state should be hidden, hide.
        if (initialState && initialState.toLowerCase() == 'hide') {
            toggleArchive(archive);
        }
    }
}

function changeText(el, newText) {
    // Safari work around
    if (el.innerText) {
        el.innerText = newText;
    } else if (el.firstChild && el.firstChild.nodeValue) {
        el.firstChild.nodeValue = newText;
    }
}

function toggleArchive(archive) {

    var archiveList = tnGetElementById(archive + 'ArchiveList');
    var toggleLink = tnGetElementById(archive + 'ArchiveToggleLink');

    // If we found the list and the link, toggle.
    if (archiveList && toggleLink) {
        if (archiveList.style.display == 'none') {
            changeText(toggleLink, 'hide');
            archiveList.style.display = 'block';
            writeCookie(document.body.id + '.' + archive + '-toggle-state', 'show', null);
    } else {
            changeText(toggleLink, 'show');
            archiveList.style.display = 'none';
            writeCookie(document.body.id + '.' + archive + '-toggle-state', 'hide', null);
        }
    }
}

function splitSelect(selectId) {
    /* Since this function just replaces a standard element with a more user-friendly one,
     * we err on the conservative side; if any error occurs, we just give up and
     * leave the original select intact.
     */
    try {
        // Get the orginal select.
        var originalSelect = tnGetElementById(selectId);

        // Create parent category SELECT element
        var parentSelect = document.createElement('SELECT');
        parentSelect.id = selectId + '-parent';
        // categoryData stores the information from the original select
        parentSelect.categoryData = new Array();

        // Iterate thru original select and save the optgroups and options.
        var optionGroup = originalSelect.firstChild;
        var categoryIndex = 0;
        var selectedCategoryIndex = 0;
        var selectedOptionIndex = 0;
        while (optionGroup) {
            // If it's an optgroup, save it.
            if (optionGroup.nodeName.toLowerCase() == 'optgroup') {
                // Create an array to hold the options
                parentSelect.categoryData[categoryIndex] = new Array();
                // Set the first element in the array to the optgroup label
                parentSelect.categoryData[categoryIndex][0] = optionGroup.label;
                // Iterate through the options and save each one
                var option = optionGroup.firstChild;
                var optionIndex = 1;
                while (option) {
                    // If it's an option, save it.
                    if (option.nodeName.toLowerCase() == 'option') {
                        // javascript lacks hash tables, so we use an array for the label and value
                        parentSelect.categoryData[categoryIndex][optionIndex] = new Array(option.innerHTML, option.value);
                        if (option.selected) {
                            selectedCategoryIndex = categoryIndex;
                            selectedOptionIndex = optionIndex - 1;
                        }
                        optionIndex++;
                    }
                    option = option.nextSibling;
                }
                categoryIndex++;
            }
            optionGroup = optionGroup.nextSibling;
        }

        // Add the original option groups to the parent select as options
        for (categoryIndex = 0; categoryIndex < parentSelect.categoryData.length; ++categoryIndex) {
            parentSelect.options[categoryIndex] = new Option(parentSelect.categoryData[categoryIndex][0]);
        }

        // Create the option select
        var optionSelect = document.createElement('SELECT');
        optionSelect.id = selectId + '-options';
        // Since the option select is going to be what the form handler sees, set its name to that of the original select
        optionSelect.name = originalSelect.name;

        // Add a reference to the option select to the parent
        parentSelect.optionSelect = optionSelect;

        // Add event listener to update the list of options when a category is selected
        parentSelect.onchange = function() {
            // Get a reference to the option select
            var optionSelect = this.optionSelect;
            // Remove the exsiting options
            optionSelect.options.length = 0;

            // Look up the array of options from the selected category and populate the option select
            var categoryIndex = this.selectedIndex;
            var optionIndex;
            for (optionIndex = 1; optionIndex < this.categoryData[categoryIndex].length; ++optionIndex) {
                var label = this.categoryData[categoryIndex][optionIndex][0];
                var value = this.categoryData[categoryIndex][optionIndex][1];
                optionSelect.options[optionIndex-1] = new Option(label, value);
            }
        }

        // Select the originally-selected category
        parentSelect.selectedIndex = selectedCategoryIndex;
        // Trigger the onChange event on the parent select to initialize the option select
        parentSelect.onchange();
        // Select the originally-selected option
        optionSelect.selectedIndex = selectedOptionIndex;

        // Insert the parent category select before the original select,
        // then replace the original select with the option select
        originalSelect.parentNode.insertBefore(parentSelect, originalSelect);
        originalSelect.parentNode.replaceChild(optionSelect, originalSelect);

        // Insert a separator between the two selects
        var separator = document.createTextNode(" / ");
        optionSelect.parentNode.insertBefore(separator, optionSelect);

        // Set the ID of the option select to that of the original select
        optionSelect.id = selectId;
    }
    catch (e) {
        // If any error occured, the parent select may have already been inserted, so remove it.
        // If the parent select doesn't exist, this will fail silently.
        try {
            originalSelect.parentNode.removeChild(parentSelect);
        }
        catch (e) {}
    }
}