#!/bin/sh

#
# fiximage.sh - Make configuration changes to the miniroot
#
#               This script is typically invoked from ant and has the
#               following arguments: 
#
#               $1: miniroot_directory
#

PROGNAME=$0
SYNTAX="${PROGNAME} minroot_directory"

. ../include/utils.sh

if [ $# != 1 ] ; then
	arg_error "miniroot_directory argument expected" "${SYNTAX}"
fi

MINIROOTDIR=$1
if [ ! -d "${MINIROOTDIR}" ] ; then
        arg_error "${MINIROOTDIR} directory does not exist" "${SYNTAX}"
fi
if [ "${MINIROOTDIR}" = "/" ] ; then
        arg_error "'/' is definitely not a valid miniroot directory" "${SYNTAX}"
fi

cd ${MINIROOTDIR}

#
# Copy usr/sfw/lib/libwrap.so.1 over to usr/lib
#
msg_to_stderr "copying some /usr/sfw/lib/ share objects over to /usr/lib"
cp ${MINIROOTDIR}/usr/sfw/lib/libwrap.so.1 ${MINIROOTDIR}/usr/lib
cp ${MINIROOTDIR}/usr/sfw/lib/libcrypto.so.0.9.7 ${MINIROOTDIR}/usr/lib

#
# Fix etc/vfstab
#
msg_to_stderr "fix /etc/vfstab"
echo "/devices/ramdisk:a - / ufs - no nologging" >> ${MINIROOTDIR}/etc/vfstab
echo "swap - /var tmpfs - yes -" >> ${MINIROOTDIR}/etc/vfstab

#
# Set nodename
#
msg_to_stderr "setting nodename"
echo "igologic" > ${MINIROOTDIR}/etc/nodename

#
# Set the timezone
#
msg_to_stderr "setting timezone"
echo "TZ=US/Eastern" > ${MINIROOTDIR}/etc/TIMEZONE

#
# Remove /var/sadm/* then tar up the /var directory.  At boot time, the
# /var directory will be untarred into a ramdisk partition.
#
msg_to_stderr "removing var/sadm/*"
rm -rf var/sadm/*
msg_to_stderr "tar up /var directory for future re-constitution"
tar cf ./var.tar ./var
/bin/rm -rf ./var/*

exit 0
