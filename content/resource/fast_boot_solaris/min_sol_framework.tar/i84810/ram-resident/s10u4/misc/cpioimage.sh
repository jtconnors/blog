#!/bin/sh

#
# cpioimage.sh - Create cpio(1) image archive of miniroot
#
#                  This script is typically invoked from ant and has the
#                  following arguments: 
#
#                  $1: base_directory
#                  $2: cpio_filename
#

PROGNAME=$0
SYNTAX="${PROGNAME} base_directory cpio_filename"

. ../include/utils.sh

if [ $# != 2 ] ; then
	arg_error "wrong number of arguments" "${SYNTAX}"
fi

BASEDIR=$1
if [ ! -d "${BASEDIR}" ] ; then
        arg_error "${BASEDIR} directory does not exist" "${SYNTAX}"
fi
if [ "${BASEDIR}" = "/" ] ; then
        arg_error "'/' is definitely not a valid base directory" "${SYNTAX}"
fi

CPIOARCHIVE=$2

BDIR=`basename ${BASEDIR}`
msg_to_stderr "archiving ${BDIR} to ${CPIOARCHIVE}"
cd ${BASEDIR}/..
find ${BDIR} -print | cpio -ocumd > ${CPIOARCHIVE}

exit 0
