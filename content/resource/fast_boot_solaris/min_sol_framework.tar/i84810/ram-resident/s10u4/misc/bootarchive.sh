#!/bin/sh

#
# bootarchive.sh - Create bootable image
#
#                  This script is typically invoked from ant and has the
#                  following arguments: 
#
#                  $1: solaris-media-root
#                  $1: base_directory
#                  $2: miniroot_directory
#                  $3: name of miniroot-image
#

PROGNAME=$0
SYNTAX="${PROGNAME} media_root base_directory minroot_directory miniroot_image"

. ../include/utils.sh

if [ $# != 4 ] ; then
	arg_error "wrong number of arguments" "${SYNTAX}"
fi

MEDIAROOT=$1
if [ ! -d "${MEDIAROOT}" ] ; then
        arg_error "${MEDIAROOT} directory does not exist" "${SYNTAX}"
fi
if [ "${MEDIAROOT}" = "/" ] ; then
        arg_error "'/' not a valid media root directory" "${SYNTAX}"
fi

BASEDIR=$2
if [ ! -d "${BASEDIR}" ] ; then
        arg_error "${BASEDIR} directory does not exist" "${SYNTAX}"
fi
if [ "${BASEDIR}" = "/" ] ; then
        arg_error "'/' not permitted as a base directory" "${SYNTAX}"
fi

MINIROOTDIR=$3
if [ ! -d "${MINIROOTDIR}" ] ; then
        arg_error "${MINIROOTDIR} directory does not exist" "${SYNTAX}"
fi
if [ "${MINIROOTDIR}" = "/" ] ; then
        arg_error "'/' is definitely not a valid miniroot directory" "${SYNTAX}"
fi

IMAGE=$4

cd ${BASEDIR}

msg_to_stderr "getting /boot from ${MEDIAROOT}"
cd ${MEDIAROOT}
tar cf - ./boot/grub | (cd ${BASEDIR}; tar xf -)
cp ${MEDIAROOT}/boot/multiboot ${BASEDIR}/boot/multiboot

#
# To have free space in the root filesystem, create a large file and delete
# it later on from the boot archive.
# 
msg_to_stderr "creating large file on / to be reclaimed as free space"
mkfile 10m ${MINIROOTDIR}/FREESPACE

msg_to_stderr "creating miniroot_archive"
/boot/solaris/bin/root_archive pack ${BASEDIR}/boot/${IMAGE} ${MINIROOTDIR}
mv ${BASEDIR}/boot/${IMAGE} ${BASEDIR}/boot/${IMAGE}.gz

#
# The root_archive command creates a filesystem with no free space.
# We'll need some headroom in this environment.  To get around this problem,
# a large file (FREESPACE) was added to the miniroot prior or to issuing the
# root_archive command.  Now remount the boot archive, remove the FREESPACE
# file and unmount it.
#
msg_to_stderr "reclaiming free space from miniroot"
gunzip ${BASEDIR}/boot/${IMAGE}.gz
LOFILE=`lofiadm -a ${BASEDIR}/boot/${IMAGE}`
if [ $? != 0 ] ; then
    errormsg_and_exit "lofiadm failed."
fi
TMPMOUNT=/tmp/lofi$$
mkdir -p ${TMPMOUNT}
mount ${LOFILE} ${TMPMOUNT}
if [ $? != 0 ] ; then
    errormsg_and_exit "mount of ${IMAGE} failed."
fi
rm ${TMPMOUNT}/FREESPACE
umount ${TMPMOUNT}
lofiadm -d ${LOFILE}
gzip ${BASEDIR}/boot/${IMAGE}

msg_to_stderr "creating grub/menu.lst"
echo "default 0" > ${BASEDIR}/boot/grub/menu.lst
echo "timeout 10" >> ${BASEDIR}/boot/grub/menu.lst
echo "title Solaris 10 U4 Embedded" >> ${BASEDIR}/boot/grub/menu.lst
echo "kernel /boot/multiboot" >> ${BASEDIR}/boot/grub/menu.lst
echo "module /boot/${IMAGE}.gz" >> ${BASEDIR}/boot/grub/menu.lst

exit 0
